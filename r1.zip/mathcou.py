
#para multiplicaciones de dos matrices
def matrixMultiplication(matrix1, matrix2):
    print(matrix1)
    print(matrix2)
    result =  [[0 for x in range(len(matrix1))] for y in range(len(matrix2[0]))]
    
    if(len(matrix1[0])== len(matrix2)):
        print("Tamaño valido")
        
        for i in range(0, len(matrix1)):
            for j in range(len(matrix2[0])):
                for k in range(len(matrix2)):
                    result[i][j] += matrix1[i][k] * matrix2[k][j]
                # local=0
                # value1= matrix1[j][j] * matrix2[j][i]
                # value2= matrix1[][j] * matrix2[j][i]
                # value3= matrix1[j][j]*matrix2[j][i]
                # result = value1+value2+value3
        print(result)
                
        
    
    else:
        print("Tamaño Invalido")
    



#para operacion de un vectori y una matriz
def matrixVectorMultiplication (matrix1, vector):
    
    pass


matrix1= [[5,2,4],[2,1,1],[1,2,3]]
matrix2 = [[1,0,2],[4,3,1],[2,0,3]]

matrix3= [[12,7,3],[4 ,5,6],[7 ,8,9]]
matrix4= [[5,8,1,2],[6,7,3,0],[4,5,9,1]]

# resultadoMatrices= matrixMultiplication(matrix1,matrix2)
resultadoMatrices= matrixMultiplication(matrix1,matrix2)