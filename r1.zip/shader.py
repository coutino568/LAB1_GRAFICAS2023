


def vertexShader(vertex,**kwargs):
	transformedVertex= vertex
	return transformedVertex

def fragmentShader(**kwargs):
	color = (1,1,1)
	return color