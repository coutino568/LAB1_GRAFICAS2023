
import random
from gl import Renderer

from obj import *
from mathcou import *

from collections import namedtuple

objetos =[]


V2 = namedtuple('Point2', ['x', 'y'])



windoWidth = 1920*1
windowHeight = 1080*1
scale= 1
viewportWidth= windoWidth*scale
viewportHeight= windowHeight *scale
viewportX=0
viewportY=0



myRenderer = Renderer(windoWidth, windowHeight)
myRenderer.glViewPort(viewportX,viewportY,viewportWidth,viewportHeight)



vertex1 = V2(50,50)
vertex2 = V2(305,750)
vertex3 = V2(650,800)
 

# myRenderer.glTriangle(750,50,700,100,900,200)
# myRenderer.glTriangle(750,10,00,00,500,200)
myRenderer.glTriangle(vertex1[0],vertex1[1],360,100,90,500)
myRenderer.glTriangle2(vertex1,vertex2,vertex3)



matrix1= [[1,2,3],[2,6,9],[5,0,4]]
matrix2 = [[3,6,1],[8,0,7],[1,0,42]]


resultadoMatrices= matrixVectorMultiplication(matrix1,matrix2)
objetito = Object("object.obj")

objetos.append(objetito)


## dibujara los objetos en el origen por el momento pero hay que hacer el pipeline de transformaciones.
for objeto in objetos:
    for vertex in objeto.vertices:
        myRenderer.glVertex(vertex[0],vertex[1])


myRenderer.glFinish("output.bmp")